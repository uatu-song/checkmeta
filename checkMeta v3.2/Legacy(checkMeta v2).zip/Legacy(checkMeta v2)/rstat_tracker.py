"""
META Fantasy League Simulator - Enhanced rStat Tracking System
Handles tracking, validation, and processing of result statistics
"""

import os
import json
import csv
import datetime
from collections import defaultdict
from typing import Dict, List, Any, Optional

class RStatTracker:
    """Enhanced system for tracking, validating, and processing result statistics"""
    
    def __init__(self):
        """Initialize the rStat tracker"""
        # Dictionary to store all unit stats
        self.unit_stats = defaultdict(lambda: defaultdict(int))
        
        # Dictionary to store team stats
        self.team_stats = defaultdict(lambda: defaultdict(int))
        
        # Define canonical rStats
        self.canonical_rstats = self._get_canonical_rstats()
    
    def _get_canonical_rstats(self):
        """Get the canonical rStat definitions
        
        Returns:
            dict: Dictionary of canonical rStat definitions
        """
        return {
            # Shared stats (used by both divisions)
            "DD": {
                "name": "Damage Dealt",
                "domain": "b",
                "description": "Total damage inflicted on opponents"
            },
            "DS": {
                "name": "Damage Sustained",
                "domain": "b",
                "description": "Total damage received from opponents"
            },
            "OTD": {
                "name": "Opponent Takedown",
                "domain": "b",
                "description": "Successfully defeating an opponent"
            },
            "AST": {
                "name": "Assists",
                "domain": "b",
                "description": "Contributing to an opponent's defeat without landing the final blow"
            },
            "ULT": {
                "name": "Ultimate Move Impact",
                "domain": "b",
                "description": "Successful execution of a character's ultimate ability"
            },
            "LVS": {
                "name": "Lives Saved",
                "domain": "b",
                "description": "Preventing an ally from being defeated"
            },
            "LLS": {
                "name": "Lives Lost",
                "domain": "b",
                "description": "Instances of ally defeat"
            },
            "CTT": {
                "name": "Counterattacks",
                "domain": "b",
                "description": "Successful defensive attacks"
            },
            "EVS": {
                "name": "Evasion Success",
                "domain": "b",
                "description": "Successfully avoiding enemy attacks"
            },
            "HLG": {
                "name": "Healing",
                "domain": "b",
                "description": "Total healing provided to allies"
            },
            "WIN": {
                "name": "Matches Won",
                "domain": "b",
                "description": "Number of matches won"
            },
            "LOSS": {
                "name": "Matches Lost",
                "domain": "b",
                "description": "Number of matches lost"
            },
            "DRAW": {
                "name": "Matches Drawn",
                "domain": "b",
                "description": "Number of matches drawn"
            },
            
            # Operations division specific
            "CVo": {
                "name": "Convergence Victory",
                "domain": "o",
                "description": "Winning a convergence battle (Operations)"
            },
            "DVo": {
                "name": "Defensive Victory",
                "domain": "o",
                "description": "Successfully defending against an attack (Operations)"
            },
            "KNBo": {
                "name": "Knockbacks",
                "domain": "o",
                "description": "Pushing back opponents with forceful attacks (Operations)"
            },
            "DDo": {
                "name": "Damage Dealt - Ops",
                "domain": "o",
                "description": "Damage dealt by Operations characters"
            },
            "DSo": {
                "name": "Damage Sustained - Ops",
                "domain": "o",
                "description": "Damage taken by Operations characters"
            },
            
            # Intelligence division specific
            "MBi": {
                "name": "Mind Break",
                "domain": "i",
                "description": "Winning a convergence battle (Intelligence)"
            },
            "ILSi": {
                "name": "Illusion Success",
                "domain": "i",
                "description": "Successfully creating tactical illusions (Intelligence)"
            },
            "DDi": {
                "name": "Damage Dealt - Intel",
                "domain": "i",
                "description": "Damage dealt by Intelligence characters"
            },
            "DSi": {
                "name": "Damage Sustained - Intel",
                "domain": "i",
                "description": "Damage taken by Intelligence characters"
            }
        }
    
    def register_character(self, character):
        """Register a character for stat tracking
        
        Args:
            character: Character to register
        """
        char_id = character.get("id", "unknown")
        self.unit_stats[char_id]["unit_id"] = char_id
        self.unit_stats[char_id]["name"] = character.get("name", "Unknown")
        self.unit_stats[char_id]["division"] = character.get("division", "o")
        self.unit_stats[char_id]["role"] = character.get("role", "")
        self.unit_stats[char_id]["team_id"] = character.get("team_id", "")
        
        # Initialize rStats if needed
        if "rStats" not in character:
            character["rStats"] = {}
    
    def update_stat(self, character, stat_name, value=1, operation="add"):
        """Update a specific stat for a character
        
        Args:
            character: Character to update
            stat_name: Name of stat to update (with or without 'r' prefix)
            value: Value to add/set
            operation: 'add' (default), 'set', or 'max'
            
        Returns:
            dict: Updated rStats
        """
        # Get character ID
        char_id = character.get("id", "unknown")
        
        # Strip 'r' prefix if present
        base_stat = stat_name[1:] if stat_name.startswith('r') else stat_name
        
        # Add 'r' prefix for storage
        full_stat_name = f"r{base_stat}"
        
        # Ensure rStats exists
        if "rStats" not in character:
            character["rStats"] = {}
        
        # Update based on operation type
        if operation == "add":
            character["rStats"][full_stat_name] = character["rStats"].get(full_stat_name, 0) + value
        elif operation == "set":
            character["rStats"][full_stat_name] = value
        elif operation == "max":
            character["rStats"][full_stat_name] = max(character["rStats"].get(full_stat_name, 0), value)
        
        # Also update in tracking dictionary
        self.unit_stats[char_id][full_stat_name] = character["rStats"][full_stat_name]
        
        return character["rStats"]
    
    def update_team_stat(self, team_id, stat_name, value=1, operation="add"):
        """Update a team-level stat
        
        Args:
            team_id: ID of team to update
            stat_name: Name of stat to update (with or without 't' prefix)
            value: Value to add/set
            operation: 'add' (default), 'set', or 'max'
        """
        # Strip 't' prefix if present
        base_stat = stat_name[1:] if stat_name.startswith('t') else stat_name
        
        # Add 't' prefix for storage
        full_stat_name = f"t{base_stat}"
        
        # Update based on operation type
        if operation == "add":
            self.team_stats[team_id][full_stat_name] += value
        elif operation == "set":
            self.team_stats[team_id][full_stat_name] = value
        elif operation == "max":
            self.team_stats[team_id][full_stat_name] = max(self.team_stats[team_id][full_stat_name], value)
    
    def track_combat_event(self, character, event_type, value=1, opponent=None, context=None):
        """Track a combat-related event
        
        Args:
            character: Character experiencing the event
            event_type: Type of combat event
            value: Value of the event
            opponent: Optional opponent character
            context: Optional additional context
        """
        # Get character properties
        division = character.get("division", "o")
        
        # Map events to stats
        event_to_stat = {
            # General stats
            "damage_dealt": "DD",
            "damage_taken": "DS",
            "ko_caused": "OTD",
            "assist": "AST",
            "ultimate_move": "ULT",
            "lives_saved": "LVS",
            "evasion": "EVS",
            "healing": "HLG",
            
            # Specific stats
            "convergence_win": "CVo" if division == "o" else "MBi",
            "counterattack": "CTT",
            "illusion": "ILSi",
            "knockback": "KNBo"
        }
        
        # Update appropriate stat
        if event_type in event_to_stat:
            stat_name = event_to_stat[event_type]
            
            # Add division suffix for damage stats
            if stat_name == "DD" or stat_name == "DS":
                stat_name = f"{stat_name}{division}"
                
            self.update_stat(character, stat_name, value)
        
        # Special handling for KO events
        if event_type == "ko_caused" and opponent:
            # Update team KO stats
            team_id = character.get("team_id", "unknown")
            opp_team_id = opponent.get("team_id", "unknown")
            
            self.update_team_stat(team_id, "KO_CAUSED", 1)
            self.update_team_stat(opp_team_id, "KO_SUFFERED", 1)
            
            # Special handling for Field Leader KO
            if opponent.get("role") == "FL":
                self.update_team_stat(team_id, "FL_KO_CAUSED", 1)
                self.update_team_stat(opp_team_id, "FL_KO_SUFFERED", 1)
    
    def record_match_result(self, character, result):
        """Record match result for a character
        
        Args:
            character: Character to update
            result: Match result ("win", "loss", "draw", "bench")
        """
        # Map result to stat
        if result == "win":
            self.update_stat(character, "WIN", 1)
        elif result == "loss":
            self.update_stat(character, "LOSS", 1)
        elif result == "draw":
            self.update_stat(character, "DRAW", 1)
        
        # Update team stats
        team_id = character.get("team_id", "unknown")
        
        if result == "win":
            self.update_team_stat(team_id, "WINS", 1)
        elif result == "loss":
            self.update_team_stat(team_id, "LOSSES", 1)
        elif result == "draw":
            self.update_team_stat(team_id, "DRAWS", 1)
    
    def validate_rstats(self, character):
        """Validate and normalize rStats for a character
        
        Args:
            character: Character to validate stats for
            
        Returns:
            dict: Validated rStats
        """
        # Get character division
        division = character.get("division", "o")
        
        # Ensure rStats exists
        if "rStats" not in character:
            character["rStats"] = {}
        
        # Get current rStats
        rstats = character["rStats"]
        
        # Check each stat against canonical definitions
        validated = {}
        
        for stat_name, stat_value in rstats.items():
            # Strip 'r' prefix if present
            base_stat = stat_name[1:] if stat_name.startswith('r') else stat_name
            
            # Check if stat is in canonical list
            if base_stat in self.canonical_rstats:
                stat_def = self.canonical_rstats[base_stat]
                
                # Check if stat is valid for this division
                if stat_def["domain"] == "b" or stat_def["domain"] == division:
                    # Add 'r' prefix for storage
                    validated[f"r{base_stat}"] = stat_value
        
        # Update character's rStats
        character["rStats"] = validated
        
        return validated
    
    def export_stats_to_csv(self, output_path=None):
        """Export tracked stats to CSV files
        
        Args:
            output_path: Base path for output files
            
        Returns:
            tuple: Paths to character and team stats CSV files
        """
        # Generate default path if none provided
        if output_path is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_dir = "results/stats"
            os.makedirs(output_dir, exist_ok=True)
            output_path = os.path.join(output_dir, f"rstats_{timestamp}")
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Export character stats
        char_path = f"{output_path}_characters.csv"
        
        with open(char_path, "w", newline="") as f:
            # Get all possible fields
            meta_fields = ["unit_id", "name", "division", "role", "team_id"]
            stat_fields = []
            
            for unit_stats in self.unit_stats.values():
                for key in unit_stats.keys():
                    if key.startswith('r') and key not in stat_fields and key not in meta_fields:
                        stat_fields.append(key)
            
            # Sort stat fields
            stat_fields.sort()
            
            # Create CSV writer
            writer = csv.DictWriter(f, fieldnames=meta_fields + stat_fields)
            writer.writeheader()
            
            # Write character stats
            for unit_id, stats in self.unit_stats.items():
                writer.writerow(stats)
        
        # Export team stats
        team_path = f"{output_path}_teams.csv"
        
        with open(team_path, "w", newline="") as f:
            # Get all possible fields
            fields = ["team_id"]
            
            for team_stats in self.team_stats.values():
                for key in team_stats.keys():
                    if key not in fields:
                        fields.append(key)
            
            # Sort fields
            fields.sort()
            
            # Create CSV writer
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            
            # Write team stats
            for team_id, stats in self.team_stats.items():
                row = {"team_id": team_id}
                row.update(stats)
                writer.writerow(row)
        
        # Export stat definitions for reference
        def_path = f"{output_path}_definitions.json"
        
        with open(def_path, "w") as f:
            json.dump(self.canonical_rstats, f, indent=2)
        
        return char_path, team_path, def_path
    
    def export_stats_to_json(self, output_path=None):
        """Export tracked stats to JSON files
        
        Args:
            output_path: Base path for output files
            
        Returns:
            tuple: Paths to character and team stats JSON files
        """
        # Generate default path if none provided
        if output_path is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_dir = "results/stats"
            os.makedirs(output_dir, exist_ok=True)
            output_path = os.path.join(output_dir, f"rstats_{timestamp}")
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Export character stats
        char_path = f"{output_path}_characters.json"
        
        with open(char_path, "w") as f:
            json.dump(dict(self.unit_stats), f, indent=2)
        
        # Export team stats
        team_path = f"{output_path}_teams.json"
        
        with open(team_path, "w") as f:
            json.dump(dict(self.team_stats), f, indent=2)
        
        return char_path, team_path