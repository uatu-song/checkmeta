"""
META Fantasy League Simulator - Enhanced Convergence System
Handles detection and resolution of convergences between chess boards
"""

import random
import math
import chess
from typing import Dict, List, Any, Optional

class ConvergenceSystem:
    """System for detecting and resolving convergences between chess boards"""
    
    def __init__(self, trait_system=None):
        """Initialize the convergence system
        
        Args:
            trait_system: Optional TraitSystem for trait activations
        """
        self.trait_system = trait_system
        
        # Balance constants
        self.BASE_DAMAGE_REDUCTION = 30  # Base 30% damage reduction
        self.MAX_DAMAGE_REDUCTION = 85   # Cap at 85% damage reduction
        self.DAMAGE_SCALING = 3         # Base damage scaling factor
        self.CRITICAL_THRESHOLD = 30    # Difference for critical convergence
    
    def process_convergences(self, team_a, team_a_boards, team_b, team_b_boards, 
                            context, max_per_char, show_details=True):
        """Process convergences between boards with improved balance
        
        Args:
            team_a: Team A characters
            team_a_boards: Team A chess boards
            team_b: Team B characters
            team_b_boards: Team B chess boards
            context: Match context
            max_per_char: Maximum convergences per character
            show_details: Whether to show detailed output
            
        Returns:
            List: Processed convergences
        """
        convergences = []
        
        # BALANCE: Limit the number of convergences per round to prevent overwhelming damage
        max_convergences = 30  # Maximum total convergences per round
        convergence_count = 0
        char_convergence_counts = {char["id"]: 0 for char in team_a + team_b}
        
        # First collect all possible convergences
        possible_convergences = []
        
        # Check for non-pawn pieces occupying the same square across different boards
        for a_idx, (a_char, a_board) in enumerate(zip(team_a, team_a_boards)):
            # Skip if character is KO'd or dead
            if a_char.get("is_ko", False) or a_char.get("is_dead", False):
                continue
                
            # Skip if character has reached max convergences
            if char_convergence_counts[a_char["id"]] >= max_per_char:
                continue
                
            for b_idx, (b_char, b_board) in enumerate(zip(team_b, team_b_boards)):
                # Skip if character is KO'd or dead
                if b_char.get("is_ko", False) or b_char.get("is_dead", False):
                    continue
                
                # Skip if character has reached max convergences
                if char_convergence_counts[b_char["id"]] >= max_per_char:
                    continue
                
                # Find overlapping positions with non-pawn pieces
                for square in chess.SQUARES:
                    a_piece = a_board.piece_at(square)
                    b_piece = b_board.piece_at(square)
                    
                    if (a_piece and b_piece and 
                        a_piece.piece_type != chess.PAWN and 
                        b_piece.piece_type != chess.PAWN):
                        
                        # Calculate combat rolls
                        a_roll = self.calculate_combat_roll(a_char, b_char)
                        b_roll = self.calculate_combat_roll(b_char, a_char)
                        
                        # Apply trait effects for convergence
                        if self.trait_system:
                            # Create context for trait activation
                            a_context = {"opponent": b_char, "square": square, "roll": a_roll}
                            a_effects = self.trait_system.apply_trait_effect(a_char, "convergence", a_context)
                            
                            for effect in a_effects:
                                if effect.get("effect") == "combat_bonus":
                                    a_roll += effect.get("value", 0)
                                    context["trait_logs"].append({
                                        "round": context.get("round", 1),
                                        "character": a_char["name"],
                                        "trait": effect.get("trait_name", "Unknown Trait"),
                                        "effect": f"Added {effect.get('value', 0)} to combat roll"
                                    })
                            
                            # Same for B character
                            b_context = {"opponent": a_char, "square": square, "roll": b_roll}
                            b_effects = self.trait_system.apply_trait_effect(b_char, "convergence", b_context)
                            
                            for effect in b_effects:
                                if effect.get("effect") == "combat_bonus":
                                    b_roll += effect.get("value", 0)
                                    context["trait_logs"].append({
                                        "round": context.get("round", 1),
                                        "character": b_char["name"],
                                        "trait": effect.get("trait_name", "Unknown Trait"),
                                        "effect": f"Added {effect.get('value', 0)} to combat roll"
                                    })
                        
                        # Calculate priority (higher difference = more important convergence)
                        priority = abs(a_roll - b_roll)
                        
                        # Store as possible convergence
                        possible_convergences.append({
                            "a_char": a_char,
                            "b_char": b_char,
                            "a_idx": a_idx,
                            "b_idx": b_idx,
                            "a_roll": a_roll,
                            "b_roll": b_roll,
                            "square": square,
                            "priority": priority
                        })
        
        # Sort by priority (highest first) and take only max_convergences
        possible_convergences.sort(key=lambda x: x["priority"], reverse=True)
        selected_convergences = possible_convergences[:max_convergences]
        
        # Now process the selected convergences
        for conv in selected_convergences:
            a_char = conv["a_char"]
            b_char = conv["b_char"]
            a_roll = conv["a_roll"]
            b_roll = conv["b_roll"]
            square = conv["square"]
            
            # Skip if either character has reached max convergences
            if char_convergence_counts[a_char["id"]] >= max_per_char or char_convergence_counts[b_char["id"]] >= max_per_char:
                continue
            
            # Determine winner and loser
            if a_roll > b_roll:
                winner = a_char
                loser = b_char
                winner_roll = a_roll
                loser_roll = b_roll
            else:
                winner = b_char
                loser = a_char
                winner_roll = b_roll
                loser_roll = a_roll
            
            # Calculate convergence outcome
            roll_diff = winner_roll - loser_roll
            outcome = "success"
            
            if roll_diff > self.CRITICAL_THRESHOLD:
                outcome = "critical_success"
            
            # Calculate damage with diminishing returns
            # Use a logarithmic scale to reduce extreme differences
            base_damage = max(1, int(self.DAMAGE_SCALING * math.log(1 + roll_diff/10)))
            
            # Apply damage reduction (for defense traits, etc.)
            damage_reduction = 0
            if self.trait_system:
                damage_context = {"damage": base_damage, "source": winner}
                reduction_effects = self.trait_system.apply_trait_effect(loser, "damage_reduction", damage_context)
                
                for effect in reduction_effects:
                    if effect.get("effect") == "damage_reduction":
                        damage_reduction += effect.get("value", 0)
                        context["trait_logs"].append({
                            "round": context.get("round", 1),
                            "character": loser["name"],
                            "trait": effect.get("trait_name", "Unknown Trait"),
                            "effect": f"Reduced damage by {effect.get('value', 0)}%"
                        })
            
            # Calculate final damage with reduction
            total_reduction = min(self.MAX_DAMAGE_REDUCTION, self.BASE_DAMAGE_REDUCTION + damage_reduction)
            reduced_damage = max(1, base_damage * (1 - total_reduction/100.0))
            
            # Apply damage to loser
            self.apply_damage(loser, reduced_damage, winner, context)
            
            # Record convergence
            convergence_data = {
                "square": chess.square_name(square),
                "a_character": a_char["name"],
                "b_character": b_char["name"],
                "a_roll": a_roll,
                "b_roll": b_roll,
                "winner": winner["name"],
                "loser": loser["name"],
                "damage": base_damage,
                "reduced_damage": reduced_damage,
                "outcome": outcome
            }
            
            convergences.append(convergence_data)
            context["convergence_logs"].append(convergence_data)
            
            # Update rStats for winner and loser
            winner.setdefault("rStats", {})
            loser.setdefault("rStats", {})
            
            # Record convergence win
            if winner.get("division") == "o":
                winner["rStats"]["rCVo"] = winner["rStats"].get("rCVo", 0) + 1
            else:
                winner["rStats"]["rMBi"] = winner["rStats"].get("rMBi", 0) + 1
            
            # Record ultimate move for critical success
            if outcome == "critical_success":
                winner["rStats"]["rULT"] = winner["rStats"].get("rULT", 0) + 1
            
            # Update convergence counts
            char_convergence_counts[a_char["id"]] += 1
            char_convergence_counts[b_char["id"]] += 1
            convergence_count += 1
            
            if show_details:
                print(f"CONVERGENCE: {a_char['name']} ({a_roll}) vs {b_char['name']} ({b_roll}) at {chess.square_name(square)}")
                print(f"  {winner['name']} wins! {loser['name']} takes {reduced_damage:.1f} damage")
                if outcome == "critical_success":
                    print(f"  CRITICAL SUCCESS! {winner['name']} recorded an Ultimate Move")
        
        return convergences
    
    def calculate_combat_roll(self, attacker, defender):
        """Calculate combat roll for convergence resolution
        
        Args:
            attacker: Attacking character
            defender: Defending character
            
        Returns:
            int: Combat roll value
        """
        # Base roll (1-100)
        roll = random.randint(1, 100)
        
        # Add stat bonuses
        str_val = attacker.get("aSTR", 5)
        fs_val = attacker.get("aFS", 5)
        
        roll += str_val + fs_val
        
        # Scale by Power Potential
        op_factor = attacker.get("aOP", 5) / 5.0
        roll = int(roll * op_factor)
        
        # Apply morale factor
        morale = attacker.get("morale", 50) / 50.0
        roll = int(roll * morale)
        
        # Apply momentum modifiers
        momentum_state = attacker.get("momentum_state", "stable")
        if momentum_state == "building":
            roll = int(roll * 1.1)  # 10% boost in building momentum
        elif momentum_state == "crash":
            roll = int(roll * 0.9)  # 10% penalty in crash momentum
        
        # Apply role bonuses
        role = attacker.get("role", "")
        if role == "FL":  # Field Leader
            roll += 10  # +10 to rolls
        elif role == "VG":  # Vanguard
            roll += 5   # +5 to rolls
        elif role == "SV":  # Sovereign
            roll += 15  # +15 to rolls
        
        return roll
    
    def apply_damage(self, character, damage, source, context):
        """Apply damage to character from convergence
        
        Args:
            character: Character taking damage
            damage: Amount of damage
            source: Source character dealing damage
            context: Match context
            
        Returns:
            dict: Damage application results
        """
        # Apply to HP first
        current_hp = character.get("HP", 100)
        new_hp = max(0, current_hp - damage)
        character["HP"] = new_hp
        
        # Update damage stats
        character.setdefault("rStats", {})
        character["rStats"]["rDS"] = character["rStats"].get("rDS", 0) + damage
        
        source.setdefault("rStats", {})
        source["rStats"]["rDD"] = source["rStats"].get("rDD", 0) + damage
        
        # Track damage contributors for assist attribution
        if "damage_contributors" in context:
            char_id = character.get("id", "unknown")
            source_id = source.get("id", "unknown")
            
            if char_id not in context["damage_contributors"]:
                context["damage_contributors"][char_id] = []
                
            if source_id not in context["damage_contributors"][char_id]:
                context["damage_contributors"][char_id].append(source_id)
        
        # Overflow to stamina if HP is depleted
        stamina_damage = 0
        if new_hp == 0:
            # Reduced stamina damage on overflow
            stamina_damage = (damage - current_hp) * 0.4
            
            current_stamina = character.get("stamina", 100)
            new_stamina = max(0, current_stamina - stamina_damage)
            character["stamina"] = new_stamina
            
            # Check for KO
            if new_stamina == 0:
                character["is_ko"] = True
                
                # Record KO stats for source
                source["rStats"]["rOTD"] = source["rStats"].get("rOTD", 0) + 1
                
                # Award assists
                if "damage_contributors" in context:
                    char_id = character.get("id", "unknown")
                    if char_id in context["damage_contributors"]:
                        for contributor_id in context["damage_contributors"][char_id]:
                            # Skip the KO source
                            if contributor_id != source.get("id", "unknown"):
                                # Find contributor and update stats
                                for team in [context.get("team_a", []), context.get("team_b", [])]:
                                    for char in team:
                                        if char.get("id") == contributor_id:
                                            char.setdefault("rStats", {})
                                            char["rStats"]["rAST"] = char["rStats"].get("rAST", 0) + 1
                                            break
        
        return {
            "damage": damage,
            "new_hp": new_hp,
            "stamina_damage": stamina_damage,
            "is_ko": character.get("is_ko", False)
        }