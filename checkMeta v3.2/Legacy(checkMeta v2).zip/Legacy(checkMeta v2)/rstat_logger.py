# rstat_logger.py
# Advanced rStat Logging System for META Fantasy League Simulator

from typing import Dict, Any, Optional, List
from systems.rstat_validator import RStatValidator

class RStatLogger:
    """
    Comprehensive logging system for result statistics across different events
    """
    
    @classmethod
    def log_convergence_stats(
        cls, 
        winner: Dict[str, Any], 
        loser: Dict[str, Any], 
        convergence_details: Dict[str, Any]
    ) -> Dict[str, int]:
        """
        Log stats for a convergence event
        
        Args:
            winner: Character who won the convergence
            loser: Character who lost the convergence
            convergence_details: Detailed information about the convergence
        
        Returns:
            Validated stats logged for the winner and loser
        """
        # Extract convergence outcome and material loss
        outcome = convergence_details.get('outcome', 'none')
        material_loss = convergence_details.get('damage', 0)
        
        # Prepare winner stats
        winner_stats = {
            # Damage Dealt based on material loss
            'rDD': int(material_loss),
            
            # Ultimate Move Impact for critical success
            'rULT': 1 if outcome == 'critical_success' else 0,
            
            # Division-specific stats
            'rCVo' if winner.get('division') == 'o' else 'rMBi': 1
        }
        
        # Prepare loser stats
        loser_stats = {
            # Damage Sustained
            'rDS': int(material_loss),
            
            # Possible additional stats based on outcome
            'rLLS': 1 if outcome in ['loss', 'critical_loss'] else 0
        }
        
        # Create instance of the validator class
        rstat_validator = RStatValidator()

        # Validate and log stats
        validated_winner_stats = rstat_validator.validate_stats(winner, winner_stats)
        validated_loser_stats = rstat_validator.validate_stats(loser, loser_stats)
        
        return {
            'winner_stats': validated_winner_stats,
            'loser_stats': validated_loser_stats
        }
    
    @classmethod
    def log_damage_event(
        cls, 
        attacker: Dict[str, Any], 
        defender: Dict[str, Any], 
        damage: float,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, int]:
        """
        Log stats for a damage event
        
        Args:
            attacker: Character dealing damage
            defender: Character receiving damage
            damage: Amount of damage dealt
            context: Optional context information
        
        Returns:
            Validated stats logged for the attacker and defender
        """
        # Create instance of the validator class
        rstat_validator = RStatValidator()
        
        # Prepare attacker stats
        attacker_stats = {
            # Damage Dealt
            'rDD': int(damage),
            
            # Opponent Takedown if defender is defeated
            'rOTD': 1 if defender.get('HP', 0) <= 0 else 0
        }
        
        # Prepare defender stats
        defender_stats = {
            # Damage Sustained
            'rDS': int(damage),
            
            # Possible Lives Lost
            'rLLS': 1 if defender.get('HP', 0) <= 0 else 0
        }
        
        # Add context-specific stats if available
        if context:
            # Example: Track assists
            if 'assisters' in context:
                for assister in context['assisters']:
                    assister_stats = {'rAST': 1}
                    assister_stats = rstat_validator.validate_stats(assister, assister_stats)

        # Validate stats
        validated_attacker_stats = rstat_validator.validate_stats(attacker, attacker_stats)
        validated_defender_stats = rstat_validator.validate_stats(defender, defender_stats)
        
        return {
            'attacker_stats': validated_attacker_stats,
            'defender_stats': validated_defender_stats
        }
    
    @classmethod
    def log_match_result(
        cls, 
        characters: List[Dict[str, Any]], 
        match_result: str
    ) -> Dict[str, Dict[str, int]]:
        """
        Log stats for match results
        
        Args:
            characters: List of characters in the match
            match_result: Overall match result ('win', 'loss', 'draw')
        
        Returns:
            Validated stats for each character
        """
        # Mapping of match results to stats
        result_stat_map = {
            'win': {'rWIN': 1, 'rDD': 25},
            'loss': {'rLLS': 1},
            'draw': {'rDRAW': 1}
        }
        
        # Track stats for each character
        character_stats = {}
        
        for character in characters:
            # Get base stats for match result
            base_stats = result_stat_map.get(match_result, {})
            
            # Create instance of the validator class
            rstat_validator = RStatValidator()
            validated_stats = rstat_validator.validate_stats(character, base_stats)
                    
            # Store validated stats
            character_stats[character['id']] = validated_stats
        
        return character_stats
    
    @classmethod
    def log_trait_activation(
        cls, 
        character: Dict[str, Any], 
        trait: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, int]:
        """
        Log stats related to trait activation
        
        Args:
            character: Character activating the trait
            trait: Trait details
            context: Optional context information
        
        Returns:
            Validated stats for the trait activation
        """
        # Prepare stats based on trait type
        trait_stats = {}
        trait_type = trait.get('type', '').lower()
        
        # Map trait types to stats
        if trait_type == 'combat':
            trait_stats['rCTT'] = 1  # Counterattack
        elif trait_type == 'defense':
            trait_stats['rDFSo'] = 1  # Defensive Save (Ops)
        elif trait_type == 'healing':
            trait_stats['rHLG'] = 1  # Healing
        
        # Create instance of the validator class  
        rstat_validator = RStatValidator()

        # Validate stats for the character
        validated_stats = rstat_validator.validate_stats(character, trait_stats)
        
        return validated_stats

# Example usage
if __name__ == "__main__":
    # Create instance of the validator class for examples
    rstat_validator = RStatValidator()
    
    # Example characters and scenarios
    ops_attacker = {"id": "char_001", "division": "o", "HP": 100}
    intel_defender = {"id": "char_002", "division": "i", "HP": 50}
    
    # Log a damage event
    damage_stats = RStatLogger.log_damage_event(ops_attacker, intel_defender, 25)
    print("Damage Event Stats:")
    print(damage_stats)
    
    # Log a convergence
    convergence_details = {
        "outcome": "critical_success", 
        "damage": 30
    }
    convergence_stats = RStatLogger.log_convergence_stats(
        ops_attacker, intel_defender, convergence_details
    )
    print("\nConvergence Stats:")
    print(convergence_stats)
    
    # Log a match result
    match_characters = [ops_attacker, intel_defender]
    match_stats = RStatLogger.log_match_result(match_characters, 'win')
    print("\nMatch Result Stats:")
    print(match_stats)