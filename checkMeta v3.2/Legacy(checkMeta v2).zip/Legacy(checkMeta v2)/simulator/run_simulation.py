#!/usr/bin/env python3
import os
import sys

# Add the project root directory to the Python path
# This allows imports from all project subdirectories
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.insert(0, project_root)

# Now we can import from systems directory
from systems.pgn_tracker import PGNTracker
from systems.rstat_logger import RStatLogger
from systems.rstat_manager import RStatManager
from systems.rstat_validator import RStatValidator
from systems.sally_floyd import generate_sally_report, format_report

# Import the simulator
from simulator.meta_simulator import MetaLeagueSimulator

def main():
    # Initialize the simulator
    # Adjust this path to where Stockfish is installed on your system
    simulator = MetaLeagueSimulator(stockfish_path="/usr/local/bin/stockfish")

    # Create sample teams and run a match
    teams = simulator.create_sample_teams()
    team_a = teams["t001"]  # Avengers
    team_b = teams["t002"]  # Champions

    print("Starting match simulation...")
    match_result = simulator.simulate_match_batched(team_a, team_b, show_details=True)
    print("\nSimulation complete!")

if __name__ == "__main__":
    main()
