"""
META Fantasy League Simulator - Enhanced Morale System
Handles character morale, team momentum, and their effects on gameplay
"""

import random
from typing import Dict, List, Any, Tuple

class MoraleSystem:
    """System for calculating and applying morale and momentum effects"""
    
    def __init__(self):
        """Initialize the morale system"""
        # Morale thresholds
        self.morale_thresholds = {
            'very_low': 20,  # 0-20
            'low': 40,       # 21-40
            'neutral': 60,   # 41-60
            'high': 80,      # 61-80
            'very_high': 100 # 81-100
        }
        
        # Momentum thresholds
        self.momentum_thresholds = {
            'crash': -3,     # <= -3
            'building': 3    # >= 3
        }
    
    def calculate_morale_level(self, morale):
        """Calculate morale level based on value
        
        Args:
            morale (int): Morale value (0-100)
            
        Returns:
            str: Morale level ('very_low', 'low', 'neutral', 'high', 'very_high')
        """
        if morale <= self.morale_thresholds['very_low']:
            return 'very_low'
        elif morale <= self.morale_thresholds['low']:
            return 'low'
        elif morale <= self.morale_thresholds['neutral']:
            return 'neutral'
        elif morale <= self.morale_thresholds['high']:
            return 'high'
        else:
            return 'very_high'
    
    def calculate_morale_modifiers(self, morale):
        """Calculate modifiers based on morale level
        
        Args:
            morale (int): Morale value (0-100)
            
        Returns:
            dict: Dictionary of morale modifiers
        """
        # Get morale level
        level = self.calculate_morale_level(morale)
        
        # Default modifiers (no effect)
        modifiers = {
            'combat_bonus': 0,
            'defense_bonus': 0,
            'stamina_regen': 0,
            'trait_activation': 0,
            'recovery_chance': 0
        }
        
        # Apply level-based modifiers
        if level == 'very_low':
            modifiers['combat_bonus'] = -20      # -20% to combat rolls
            modifiers['defense_bonus'] = -15     # -15% to defense
            modifiers['stamina_regen'] = -2      # -2 stamina regen
            modifiers['trait_activation'] = -0.1  # -10% trait activation
            modifiers['recovery_chance'] = -0.1   # -10% recovery chance
        
        elif level == 'low':
            modifiers['combat_bonus'] = -10      # -10% to combat rolls
            modifiers['defense_bonus'] = -5      # -5% to defense
            modifiers['stamina_regen'] = -1      # -1 stamina regen
            modifiers['trait_activation'] = -0.05 # -5% trait activation
            modifiers['recovery_chance'] = -0.05  # -5% recovery chance
        
        elif level == 'high':
            modifiers['combat_bonus'] = 10       # +10% to combat rolls
            modifiers['defense_bonus'] = 5       # +5% to defense
            modifiers['stamina_regen'] = 1       # +1 stamina regen
            modifiers['trait_activation'] = 0.05  # +5% trait activation
            modifiers['recovery_chance'] = 0.05   # +5% recovery chance
        
        elif level == 'very_high':
            modifiers['combat_bonus'] = 20       # +20% to combat rolls
            modifiers['defense_bonus'] = 15      # +15% to defense
            modifiers['stamina_regen'] = 2       # +2 stamina regen
            modifiers['trait_activation'] = 0.1   # +10% trait activation
            modifiers['recovery_chance'] = 0.1    # +10% recovery chance
        
        return modifiers
    
    def update_morale(self, character, event_type, value=None):
        """Update character morale based on events
        
        Args:
            character: Character to update
            event_type: Type of event (win, loss, ko, etc.)
            value: Optional direct value to modify by
            
        Returns:
            int: New morale value
        """
        # Current morale
        current_morale = character.get("morale", 50)
        
        # Calculate change based on event
        morale_change = 0
        
        if value is not None:
            # Direct value provided
            morale_change = value
        else:
            # Calculate based on event type
            if event_type == "win":
                morale_change = 10
            elif event_type == "loss":
                morale_change = -5
            elif event_type == "draw":
                morale_change = 2
            elif event_type == "knockout":
                morale_change = -10
            elif event_type == "revival":
                morale_change = 5
            elif event_type == "critical_success":
                morale_change = 8
            elif event_type == "critical_failure":
                morale_change = -8
        
        # Apply Leadership bonus to morale change
        if morale_change > 0 and character.get("role") == "FL":
            morale_change = int(morale_change * 1.5)  # 50% bonus for Field Leaders
        
        # Apply change
        new_morale = max(0, min(100, current_morale + morale_change))
        character["morale"] = new_morale
        
        # Update morale modifiers
        character["morale_modifiers"] = self.calculate_morale_modifiers(new_morale)
        
        return new_morale
    
    def update_team_morale(self, team_a, team_b, winner):
        """Update morale for all characters on both teams based on match result
        
        Args:
            team_a: Team A characters
            team_b: Team B characters
            winner: Winner of the match ("Team A", "Team B", or "Draw")
        """
        # Determine event types
        team_a_event = "win" if winner == "Team A" else "loss" if winner == "Team B" else "draw"
        team_b_event = "win" if winner == "Team B" else "loss" if winner == "Team A" else "draw"
        
        # Update team A morale
        for character in team_a:
            self.update_morale(character, team_a_event)
        
        # Update team B morale
        for character in team_b:
            self.update_morale(character, team_b_event)
    
    def update_momentum(self, team_a_status, team_b_status, team_a_momentum, team_b_momentum):
        """Update momentum for both teams based on match status
        
        Args:
            team_a_status: Team A status (active/KO counts)
            team_b_status: Team B status (active/KO counts)
            team_a_momentum: Current team A momentum
            team_b_momentum: Current team B momentum
            
        Returns:
            tuple: (updated team A momentum, updated team B momentum)
        """
        # Calculate relative team strengths
        team_a_strength = self._calculate_team_strength(team_a_status)
        team_b_strength = self._calculate_team_strength(team_b_status)
        
        # Calculate momentum shift
        momentum_shift = self._calculate_momentum_shift(team_a_strength, team_b_strength)
        
        # Update momentum values
        team_a_momentum_value = team_a_momentum.get("value", 0) + momentum_shift
        team_b_momentum_value = team_b_momentum.get("value", 0) - momentum_shift
        
        # Cap momentum values (-5 to 5)
        team_a_momentum_value = max(-5, min(5, team_a_momentum_value))
        team_b_momentum_value = max(-5, min(5, team_b_momentum_value))
        
        # Update momentum states
        team_a_momentum_state = self._determine_momentum_state(team_a_momentum_value)
        team_b_momentum_state = self._determine_momentum_state(team_b_momentum_value)
        
        # Return updated momentum
        return (
            {"state": team_a_momentum_state, "value": team_a_momentum_value},
            {"state": team_b_momentum_state, "value": team_b_momentum_value}
        )
    
    def _calculate_team_strength(self, team_status):
        """Calculate team strength as a percentage
        
        Args:
            team_status: Team status (active/KO counts)
            
        Returns:
            float: Team strength (0-1)
        """
        active = team_status.get("active", 0)
        total = team_status.get("total", 0)
        
        if total == 0:
            return 0
            
        return active / total
    
    def _calculate_momentum_shift(self, team_a_strength, team_b_strength):
        """Calculate momentum shift based on team strengths
        
        Args:
            team_a_strength: Team A strength (0-1)
            team_b_strength: Team B strength (0-1)
            
        Returns:
            float: Momentum shift (-1 to 1)
        """
        # Calculate difference
        diff = team_a_strength - team_b_strength
        
        # Significant advantage (30%+ difference)
        if diff >= 0.3:
            return 1.0  # Major shift towards team A
        elif diff <= -0.3:
            return -1.0  # Major shift towards team B
        
        # Moderate advantage (10-30% difference)
        elif diff >= 0.1:
            return 0.5  # Moderate shift towards team A
        elif diff <= -0.1:
            return -0.5  # Moderate shift towards team B
        
        # Minor advantage (0-10% difference)
        elif diff > 0:
            return 0.2  # Minor shift towards team A
        elif diff < 0:
            return -0.2  # Minor shift towards team B
        
        # No advantage
        else:
            return 0.0  # No shift
    
    def _determine_momentum_state(self, momentum_value):
        """Determine momentum state based on value
        
        Args:
            momentum_value: Momentum value (-5 to 5)
            
        Returns:
            str: Momentum state ('crash', 'stable', 'building')
        """
        if momentum_value <= self.momentum_thresholds['crash']:
            return 'crash'
        elif momentum_value >= self.momentum_thresholds['building']:
            return 'building'
        else:
            return 'stable'
    
    def apply_momentum_effects(self, characters, momentum):
        """Apply effects based on team momentum
        
        Args:
            characters: List of characters to apply effects to
            momentum: Team momentum state and value
            
        Returns:
            dict: Applied momentum effects
        """
        # Get momentum state
        state = momentum.get("state", "stable")
        value = momentum.get("value", 0)
        
        # Initialize effects
        effects = {}
        
        # Apply state-based effects
        if state == "building":
            # Building momentum boosts offense
            effects["combat_bonus"] = 10        # +10% to combat rolls
            effects["trait_activation"] = 0.05   # +5% trait activation
            effects["stamina_cost"] = -0.1      # -10% stamina costs
        
        elif state == "crash":
            # Crash momentum activates comeback mechanics
            effects["damage_reduction"] = 15    # +15% damage reduction
            effects["recovery"] = 2             # +2 HP/stamina recovery
            effects["trait_activation"] = 0.1   # +10% trait activation
            effects["revival_chance"] = 0.1     # +10% KO recovery chance
        
        # Scale effects based on momentum value
        intensity = abs(value) / 5.0  # 0-1 scale
        
        for key in effects:
            effects[key] = effects[key] * (0.8 + (intensity * 0.4))  # Scale 80-120% based on intensity
        
        # Apply effects to characters
        for character in characters:
            character["momentum_state"] = state
            character["momentum_value"] = value
            
            # No need to store effects on character as they'll be recalculated each round
        
        return effects