#!/usr/bin/env python3
"""
META Zero Enhanced Simulator
----------------------------
A comprehensive tactical simulation engine built around role asymmetry,
narrative depth, and AI-driven combat using chess as the underlying mechanic.

This simulator combines the best components from various META League Simulator
versions with enhanced balance, parity, and realism.
"""

import os
import sys
import json
import random
import argparse
import datetime
from typing import Dict, List, Any, Tuple

# Add module directories to path
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

# Import core components
from simulator.meta_simulator import MetaLeagueSimulator
from utils.loaders import load_lineups_from_excel
from utils.match_helpers import create_team_matchups
from systems.sally_floyd import generate_sally_report, format_report

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='META Zero Enhanced Simulator')
    
    parser.add_argument('--day', type=int, default=1,
                        help='Match day number (default: 1)')
    parser.add_argument('--lineup-file', type=str, default='data/lineups/All Lineups 1.xlsx',
                        help='Excel file containing lineups')
    parser.add_argument('--stockfish-path', type=str, default='/usr/local/bin/stockfish',
                        help='Path to Stockfish chess engine')
    parser.add_argument('--output-dir', type=str, default='results',
                        help='Directory to save results')
    parser.add_argument('--verbose', action='store_true',
                        help='Show detailed output')
    parser.add_argument('--randomize', action='store_true',
                        help='Randomize matchups instead of using fixed schedule')
    parser.add_argument('--generate-reports', action='store_true',
                        help='Generate narrative reports for matches')
    parser.add_argument('--fast-mode', action='store_true',
                        help='Use fast mode (limited moves and simplified calculations)')
    parser.add_argument('--pgn-analysis', action='store_true',
                        help='Generate PGN analysis after simulation')
    parser.add_argument('--pgn-character', type=str, default=None,
                        help='Analyze PGN files for a specific character ID')
    
    return parser.parse_args()

def save_results(results, args):
    """Save match results to file"""
    # Create timestamp for filename
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Create directory if it doesn't exist
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Save as JSON
    json_file = os.path.join(args.output_dir, f"day_{args.day}_results_{timestamp}.json")
    with open(json_file, "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"Results saved to {json_file}")
    
    # Generate report if requested
    if args.generate_reports and results:
        report_dir = os.path.join(args.output_dir, "reports")
        os.makedirs(report_dir, exist_ok=True)
        
        for idx, match_result in enumerate(results):
            report = generate_sally_report(match_result)
            report_text = format_report(report)
            
            report_file = os.path.join(report_dir, f"day_{args.day}_match_{idx+1}_{timestamp}.txt")
            with open(report_file, "w") as f:
                f.write(report_text)
            
            print(f"Report for match {idx+1} saved to {report_file}")
    
    return json_file

def main():
    """Main entry point"""
    # Parse command line arguments
    args = parse_arguments()
    
    print(f"=== META Zero Enhanced Simulator ===")
    print(f"Running simulation for day {args.day}...")
    
    # Initialize simulator
    simulator = MetaLeagueSimulator(stockfish_path=args.stockfish_path)
    simulator.current_day = args.day
    
    if args.fast_mode:
        simulator.MAX_MOVES_TO_SIMULATE = 15
        simulator.MAX_CONVERGENCES_PER_CHAR = 2
        print("Running in FAST MODE with reduced moves and simplified calculations")
    
    # Load team lineups
    try:
        teams = load_lineups_from_excel(args.lineup_file, f"{args.day}/7/25")
        print(f"Loaded {len(teams)} teams from {args.lineup_file}")
        
        if args.verbose:
            for team_id, team in teams.items():
                print(f"Team {team_id}: {len(team)} characters")
    except Exception as e:
        print(f"Error loading lineups: {e}")
        return 1
    
    # Create matchups
    matchups = create_team_matchups(teams, args.day, args.randomize)
    print(f"Created {len(matchups)} matchups for day {args.day}")
    
    if args.verbose:
        for i, (team_a_id, team_b_id) in enumerate(matchups):
            print(f"Match {i+1}: {team_a_id} vs {team_b_id}")
    
    # Run simulations
    results = []
    
    for i, (team_a_id, team_b_id) in enumerate(matchups):
        print(f"\nSimulating match {i+1}: {team_a_id} vs {team_b_id}...")
        
        # Get teams
        team_a = teams.get(team_a_id, [])
        team_b = teams.get(team_b_id, [])
        
        if not team_a or not team_b:
            print(f"Error: Missing teams for matchup ({team_a_id} vs {team_b_id})")
            continue
        
        # Run simulation
        match_result = simulator.simulate_match(team_a, team_b, show_details=args.verbose)
        results.append(match_result)
        
        # Show summary
        print(f"Match result: {match_result['team_a_name']} {match_result['team_a_wins']} - {match_result['team_b_wins']} {match_result['team_b_name']}")
        print(f"Winner: {match_result['winning_team']}")
        print(f"Convergences: {match_result['convergence_count']}")
        print(f"Trait activations: {match_result['trait_activations']}")
    
    # Save results
    results_file = save_results(results, args)
    
    # PGN Analysis if requested
    if args.pgn_analysis:
        print("\nGenerating PGN Analysis...")
        
        # Get all PGN files from results directory
        pgn_dir = os.path.join(args.output_dir, "pgn")
        if os.path.exists(pgn_dir):
            pgn_files = [os.path.join(pgn_dir, f) 
                        for f in os.listdir(pgn_dir)
                        if f.endswith(".pgn")]
            
            if not pgn_files:
                print("No PGN files found for analysis")
            else:
                # Initialize PGN tracker
                from pgn_tracker import PGNTracker
                pgn_tracker = PGNTracker()
                
                # Analyze specific character if requested
                if args.pgn_character:
                    char_id = args.pgn_character
                    print(f"Analyzing games for character {char_id}...")
                    
                    char_stats = pgn_tracker.analyze_character_games(char_id, pgn_files)
                    
                    # Display character stats
                    print(f"\nStats for Character {char_id}:")
                    print(f"Total Games: {char_stats['total_games']}")
                    print(f"Record: {char_stats['wins']}W - {char_stats['losses']}L - {char_stats['draws']}D")
                    print(f"Average Moves: {char_stats['avg_moves']:.1f}")
                    print(f"Average HP Loss: {char_stats['avg_hp_loss']:.1f}")
                    
                    if char_stats['favorite_opening']:
                        print(f"Favorite Opening: {char_stats['favorite_opening']}")
                    
                    if char_stats['most_common_moves']:
                        print(f"Most Common Moves: {', '.join(char_stats['most_common_moves'][:3])}")
                
                # General analysis
                else:
                    # Analyze the most recent match
                    latest_pgn = max(pgn_files, key=os.path.getctime)
                    stats = pgn_tracker.export_pgn_statistics(latest_pgn)
                    
                    # Display stats
                    print(f"\nAnalysis of latest match ({os.path.basename(latest_pgn)}):")
                    print(f"Total Games: {stats['total_games']}")
                    print(f"Results: {stats['games_by_result']['win']}W - {stats['games_by_result']['loss']}L - {stats['games_by_result']['draw']}D")
                    print(f"Average Moves: {stats['average_moves']:.1f}")
                    
                    if stats['openings']:
                        # Find most common opening
                        most_common_opening = max(stats['openings'].items(), key=lambda x: x[1])
                        print(f"Most Common Opening: {most_common_opening[0]} (used {most_common_opening[1]} times)")
                    
                    if stats['move_frequency']:
                        # Find most common moves
                        sorted_moves = sorted(stats['move_frequency'].items(), key=lambda x: x[1], reverse=True)
                        print("Most Common Moves:")
                        for move, count in sorted_moves[:5]:
                            print(f"  {move}: {count} times")
        else:
            print(f"PGN directory not found: {pgn_dir}")
    
    print("\nSimulation complete!")
    return 0

if __name__ == "__main__":
    sys.exit(main())