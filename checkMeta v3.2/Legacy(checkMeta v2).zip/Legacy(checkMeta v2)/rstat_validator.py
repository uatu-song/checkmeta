# rstat_validator.py
# Comprehensive rStat Validation System

from typing import Dict, Any, Optional, Set

class RStatValidator:
    """
    Comprehensive validator for result statistics across different character divisions
    """
    
    # Canonical rStats with detailed domain and meaning information
    CANONICAL_STATS = {
        # Shared Stats (both divisions)
        "DD": {
            "domain": "b", 
            "meaning": "Damage Dealt",
            "description": "Total damage inflicted on opponents"
        },
        "DS": {
            "domain": "b", 
            "meaning": "Damage Sustained",
            "description": "Total damage received from opponents"
        },
        "OTD": {
            "domain": "b", 
            "meaning": "Opponent Takedown",
            "description": "Successfully defeating an opponent"
        },
        "AST": {
            "domain": "b", 
            "meaning": "Assists",
            "description": "Contributing to an opponent's defeat without landing the final blow"
        },
        "ULT": {
            "domain": "b", 
            "meaning": "Ultimate Move Impact",
            "description": "Successful execution of a character's ultimate ability"
        },
        "LVS": {
            "domain": "b", 
            "meaning": "Lives Saved",
            "description": "Preventing an ally from being defeated"
        },
        "LLS": {
            "domain": "b", 
            "meaning": "Lives Lost",
            "description": "Instances of ally defeat"
        },
        "CTT": {
            "domain": "b", 
            "meaning": "Counterattacks",
            "description": "Successful defensive attacks"
        },
        "EVS": {
            "domain": "b", 
            "meaning": "Evasion Success",
            "description": "Successfully avoiding enemy attacks"
        },
        "FFD": {
            "domain": "b", 
            "meaning": "Friendly Fire Damage",
            "description": "Damage accidentally dealt to allies"
        },
        "FFI": {
            "domain": "b", 
            "meaning": "Friendly Fire Incapacitations",
            "description": "Allies incapacitated due to friendly fire"
        },
        "HLG": {
            "domain": "b", 
            "meaning": "Healing",
            "description": "Total healing provided to allies"
        },
        
        # Operations-specific Stats
        "DFSo": {
            "domain": "o", 
            "meaning": "Defensive Saves",
            "description": "Defensive maneuvers preventing damage in Ops scenarios"
        },
        "KNBo": {
            "domain": "o", 
            "meaning": "Knockbacks and Disruptions",
            "description": "Tactical moves pushing opponents back or disrupting their formation"
        },
        "RTOo": {
            "domain": "o", 
            "meaning": "Ranged Takedown",
            "description": "Defeating opponents using ranged attacks"
        },
        "CQTo": {
            "domain": "o", 
            "meaning": "Close-Quarters Takedown",
            "description": "Defeating opponents in close combat"
        },
        "BRXo": {
            "domain": "o", 
            "meaning": "Brutal Execution",
            "description": "Overwhelming and decisive combat actions"
        },
        "HWIo": {
            "domain": "o", 
            "meaning": "Heavy Weapon Impact",
            "description": "Damage dealt using heavy weaponry"
        },
        "MOTo": {
            "domain": "o", 
            "meaning": "Multi-Opponent Takedowns",
            "description": "Defeating multiple opponents simultaneously"
        },
        "AMBo": {
            "domain": "o", 
            "meaning": "Armor Break",
            "description": "Successfully penetrating or destroying enemy armor"
        },
        
        # Intelligence-specific Stats
        "MBi": {
            "domain": "i", 
            "meaning": "Mind Break",
            "description": "Psychological disruption of enemy capabilities"
        },
        "ILSi": {
            "domain": "i", 
            "meaning": "Illusion Success",
            "description": "Successfully creating misleading perceptions"
        },
        "FEi": {
            "domain": "i", 
            "meaning": "Forced Errors",
            "description": "Causing enemies to make strategic mistakes"
        },
        "DSRi": {
            "domain": "i", 
            "meaning": "Disruption Effect",
            "description": "Interfering with enemy strategic capabilities"
        },
        "INFi": {
            "domain": "i", 
            "meaning": "Infiltration Success",
            "description": "Successfully penetrating enemy defenses or information systems"
        },
        "RSPi": {
            "domain": "i", 
            "meaning": "Reality Shift Impact",
            "description": "Manipulating perception or tactical reality"
        }
    }
    
    @classmethod
    def get_stat_domain(cls, stat: str) -> Optional[str]:
        """
        Determine the domain of a stat
        
        Args:
            stat (str): Stat abbreviation (with or without 'r' prefix)
        
        Returns:
            str or None: Domain of the stat ('b', 'o', 'i') or None if invalid
        """
        # Remove 'r' prefix if present
        clean_stat = stat[1:] if stat.startswith('r') else stat
        
        stat_info = cls.CANONICAL_STATS.get(clean_stat)
        return stat_info['domain'] if stat_info else None
    
    @classmethod
    def get_stat_meaning(cls, stat: str) -> Optional[str]:
        """
        Get the full meaning of a stat
        
        Args:
            stat (str): Stat abbreviation (with or without 'r' prefix)
        
        Returns:
            str or None: Meaning of the stat
        """
        # Remove 'r' prefix if present
        clean_stat = stat[1:] if stat.startswith('r') else stat
        
        stat_info = cls.CANONICAL_STATS.get(clean_stat)
        return stat_info['meaning'] if stat_info else None
    
    @classmethod
    def get_allowed_stats(cls, division: str) -> Set[str]:
        """
        Get all valid stats for a given division
        
        Args:
            division (str): Character division ('o', 'i', or 'b')
        
        Returns:
            Set of valid stat abbreviations
        """
        return {
            stat for stat, details in cls.CANONICAL_STATS.items()
            if details['domain'] == division or details['domain'] == 'b'
        }
    
    @classmethod
    def validate_stats(cls, character: Dict[str, Any], stats: Dict[str, int]) -> Dict[str, int]:
        """
        Validate and filter stats for a specific character
        
        Args:
            character: Character dictionary
            stats: Stats to validate
        
        Returns:
            Validated stats for the character
        """
        # Determine character's division
        division = character.get('division', 'b')
        
        # Get allowed stats for this division
        allowed_stats = cls.get_allowed_stats(division)
        
        # Filter and validate stats
        validated_stats = {}
        for stat, value in stats.items():
            # Remove 'r' prefix if present
            clean_stat = stat[1:] if stat.startswith('r') else stat
            
            # Check if stat is allowed
            if clean_stat in allowed_stats:
                validated_stats[f'r{clean_stat}'] = value
        
        return validated_stats
    
    @classmethod
    def describe_stat(cls, stat: str) -> Optional[Dict[str, str]]:
        """
        Get detailed description of a stat
        
        Args:
            stat (str): Stat abbreviation (with or without 'r' prefix)
        
        Returns:
            Detailed stat information or None
        """
        # Remove 'r' prefix if present
        clean_stat = stat[1:] if stat.startswith('r') else stat
        
        return cls.CANONICAL_STATS.get(clean_stat)

# Instantiate a global validator for easy access
rstat_validator = RStatValidator()

# Example usage and testing
if __name__ == "__main__":
    # Example character
    ops_character = {"id": "char_001", "division": "o"}
    intel_character = {"id": "char_002", "division": "i"}
    
    # Sample stats to validate
    sample_stats = {
        "rDD": 50,        # Damage Dealt (both)
        "rBRXo": 3,       # Brutal Execution (Ops only)
        "rMBi": 2,        # Mind Break (Intel only)
        "rXPBoost": 999   # Invalid stat
    }
    
    # Validate stats for Ops character
    print("Ops Character Validated Stats:")
    print(rstat_validator.validate_stats(ops_character, sample_stats))
    
    # Validate stats for Intel character
    print("\nIntel Character Validated Stats:")
    print(rstat_validator.validate_stats(intel_character, sample_stats))
    
    # Get stat descriptions
    print("\nStat Descriptions:")
    for stat in ["DD", "BRXo", "MBi"]:
        desc = rstat_validator.describe_stat(stat)
        if desc:
            print(f"{stat}: {desc['meaning']} - {desc['description']}")