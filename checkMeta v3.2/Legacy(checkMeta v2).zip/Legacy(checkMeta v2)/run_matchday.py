#!/usr/bin/env python3
import os
import sys
import json
import time
import argparse

# Add project root to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

def run_matchday(day_number=1, lineup_file="data/lineups/All Lineups 1.xlsx", show_details=True):
    """Run all matches for a specific day using real lineups"""
    from simulator.meta_simulator import MetaLeagueSimulator
    from utils.loaders import load_lineups_from_excel
    from utils.match_helpers import create_team_matchups
    
    # Initialize simulator
    simulator = MetaLeagueSimulator()
    simulator.current_day = day_number
    
    # Load real lineups
    print(f"Loading lineups from {lineup_file} for day {day_number}")
    try:
        teams = load_lineups_from_excel(lineup_file, f"{day_number}/7/25")
        print(f"Loaded {len(teams)} teams")
    except Exception as e:
        print(f"Error loading lineups: {e}")
        return
    
    # Create matchups
    matchups = create_team_matchups(teams, day_number, randomize=False)
    print(f"Created {len(matchups)} matchups for day {day_number}")
    
    if not matchups:
        print("No valid matchups found. Check team IDs in lineup file.")
        return
    
    # Run simulations for each matchup
    results = []
    for i, (team_a_id, team_b_id) in enumerate(matchups):
        try:
            team_a = teams[team_a_id]
            team_b = teams[team_b_id]
            
            print(f"\n=== Match {i+1}: {team_a[0]['team_name']} vs {team_b[0]['team_name']} ===")
            
            # Run simulation
            match_result = simulator.simulate_match_batched(team_a, team_b, show_details=show_details)
            results.append(match_result)
            
            # Brief pause between matches
            time.sleep(1)
        except KeyError as e:
            print(f"Error: Team {e} not found in loaded teams")
            continue
        except Exception as e:
            print(f"Error in match {i+1}: {e}")
            continue
    
    # Save day results
    timestamp = int(time.time())
    results_file = f"results/day_{day_number}_results_{timestamp}.json"
    os.makedirs(os.path.dirname(results_file), exist_ok=True)
    
    with open(results_file, "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\nAll matches for day {day_number} completed")
    print(f"Results saved to {results_file}")
    
    return results

def main():
    """Main entry point with command line arguments"""
    parser = argparse.ArgumentParser(description="Run META Fantasy League matches for a specific day")
    parser.add_argument("--day", type=int, default=1, help="Day number (1-5)")
    parser.add_argument("--lineup", type=str, default="data/lineups/All Lineups 1.xlsx", 
                        help="Path to lineup Excel file")
    parser.add_argument("--quiet", action="store_true", help="Hide detailed output")
    
    args = parser.parse_args()
    
    # Run the matchday
    run_matchday(
        day_number=args.day,
        lineup_file=args.lineup,
        show_details=not args.quiet
    )

if __name__ == "__main__":
    main()