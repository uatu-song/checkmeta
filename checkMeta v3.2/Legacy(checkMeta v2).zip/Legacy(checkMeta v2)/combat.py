"""
META Fantasy League Simulator - Enhanced Combat System
Handles combat mechanics, damage calculation, and move selection
"""

import random
import math
import chess
import chess.engine
import os
from typing import Dict, List, Any, Optional

class CombatSystem:
    """Enhanced system for handling combat mechanics"""
    
    def __init__(self, trait_system=None, stockfish_path=None):
        """Initialize the combat system
        
        Args:
            trait_system: Optional trait system for trait activations
            stockfish_path: Path to Stockfish chess engine executable
        """
        self.trait_system = trait_system
        self.stockfish_path = stockfish_path
        self.stockfish_available = stockfish_path and os.path.exists(stockfish_path)
        
        # Balance constants
        self.BASE_DAMAGE_REDUCTION = 30  # Base 30% damage reduction
        self.MAX_DAMAGE_REDUCTION = 85   # Cap at 85% damage reduction
        self.MATERIAL_DAMAGE_FACTOR = 3  # Damage from material is 3x the material value
        self.HP_REGEN_BASE = 5           # Base HP regeneration per round
        self.STAMINA_REGEN_BASE = 5      # Base stamina regeneration per round
        self.KO_RECOVERY_FACTOR = 3      # KO'd characters recover 3x faster
    
    def update_character_metrics(self, character, material_change, show_details=False):
        """Update character metrics based on material change with improved balance
        
        Args:
            character: Character to update
            material_change: Chess material change
            show_details: Whether to show detailed output
        """
        # Material loss = damage
        if material_change < 0:
            # Calculate damage from material loss
            damage = abs(material_change) * self.MATERIAL_DAMAGE_FACTOR
            
            # Calculate damage reduction from DUR/RES stats
            reduction = 0
            
            # Durability gives damage reduction
            dur_bonus = (character.get("aDUR", 5) - 5) * 3  # 3% per point above 5
            reduction += dur_bonus
            
            # Resilience gives damage reduction
            res_bonus = (character.get("aRES", 5) - 5) * 2  # 2% per point above 5
            reduction += res_bonus
            
            # Apply damage reduction from traits
            trait_reduction = 0
            if self.trait_system:
                context = {"damage": damage, "source": "material_loss"}
                trait_effects = self.trait_system.apply_trait_effect(
                    character, "damage_taken", context
                )
                
                for effect in trait_effects:
                    if effect.get("effect") == "damage_reduction":
                        trait_reduction += effect.get("value", 0)
            
            # Apply total damage reduction
            total_reduction = self.BASE_DAMAGE_REDUCTION + reduction + trait_reduction
            total_reduction = min(total_reduction, self.MAX_DAMAGE_REDUCTION)  # Cap at max
            
            reduced_damage = max(1, damage * (1 - total_reduction/100.0))
            
            # Apply damage to character
            self.apply_damage(character, reduced_damage)
            
            # Update rStats for damage sustained
            character.setdefault("rStats", {})
            character["rStats"]["rDS"] = character["rStats"].get("rDS", 0) + reduced_damage
            
            if character.get("division") == "o":
                character["rStats"]["rDSo"] = character["rStats"].get("rDSo", 0) + reduced_damage
            
            if show_details:
                print(f"  {character['name']} took {reduced_damage:.1f} damage")
                print(f"  {character['name']} HP: {character['HP']:.1f}, Stamina: {character['stamina']:.1f}, Life: {character['life']:.1f}")
        
        # Material gain = damage dealt to opponent
        elif material_change > 0:
            # Calculate damage dealt
            damage_dealt = material_change * self.MATERIAL_DAMAGE_FACTOR
            
            # Update rStats for damage dealt
            character.setdefault("rStats", {})
            character["rStats"]["rDD"] = character["rStats"].get("rDD", 0) + damage_dealt
            
            if character.get("division") == "o":
                character["rStats"]["rDDo"] = character["rStats"].get("rDDo", 0) + damage_dealt
                
            # If material gain is significant, record special stat
            if material_change >= 4:
                if character.get("division") == "i":
                    character["rStats"]["rMBi"] = character["rStats"].get("rMBi", 0) + 1
                else:
                    character["rStats"]["rCVo"] = character["rStats"].get("rCVo", 0) + 1
        
        # Apply stamina cost for moving
        stamina_cost = 1.0
        
        # Apply WIL bonus to reduce stamina cost with improved scaling
        wil_bonus = (character.get("aWIL", 5) - 5) * 0.08  # 8% reduction per point above 5
        stamina_cost *= max(0.3, 1 - wil_bonus)  # Cap at 70% reduction
        
        character["stamina"] = max(0, character.get("stamina", 100) - stamina_cost)
    
    def apply_damage(self, character, damage, source_character=None, damage_reduction=0, context=None):
        """Apply damage to a character with improved survivability and knockdown mechanics
        
        Args:
            character: Character taking damage
            damage: Amount of damage
            source_character: Character dealing damage (optional)
            damage_reduction: Additional damage reduction percentage (0-100)
            context: Additional context for damage application
            
        Returns:
            Dict: Damage application results
        """
        context = context or {}
        damage = float(damage)  # Ensure damage is a float for calculations
        
        # Apply to HP first with improved reduction
        current_hp = character.get("HP", 100)
        
        # Calculate base reduction
        base_reduction = self.BASE_DAMAGE_REDUCTION + damage_reduction
        
        # Additional reduction from character attributes
        attr_reduction = 0
        dur_value = character.get("aDUR", 5)
        res_value = character.get("aRES", 5)
        
        if dur_value > 5:
            attr_reduction += (dur_value - 5) * 3  # 3% per point above 5
        
        if res_value > 5:
            attr_reduction += (res_value - 5) * 2  # 2% per point above 5
        
        # Apply momentum-based reduction
        momentum_state = character.get("momentum_state", "stable")
        momentum_reduction = 0
        
        if momentum_state == "crash":
            momentum_reduction = 15  # Additional 15% reduction when in crash state
        
        # Total reduction (capped at maximum)
        total_reduction = min(self.MAX_DAMAGE_REDUCTION, base_reduction + attr_reduction + momentum_reduction)
        
        # Apply reduction
        reduced_damage = max(1, damage * (1 - total_reduction/100.0))
        
        # Apply to HP
        new_hp = max(0, current_hp - reduced_damage)
        character["HP"] = new_hp
        
        # Update damage stats in rStats
        character.setdefault("rStats", {})
        character["rStats"]["rDS"] = character["rStats"].get("rDS", 0) + reduced_damage
        
        # Track damage by source character for assists
        if source_character and context.get("damage_contributors"):
            char_id = character.get("id", "unknown")
            source_id = source_character.get("id", "unknown")
            
            if char_id not in context["damage_contributors"]:
                context["damage_contributors"][char_id] = []
                
            if source_id not in context["damage_contributors"][char_id]:
                context["damage_contributors"][char_id].append(source_id)
        
        # Overflow to stamina if HP is depleted, but at reduced rate
        stamina_damage = 0
        if new_hp == 0:
            # BALANCE: Reduce stamina damage rate for better survivability
            stamina_damage = (reduced_damage - current_hp) * 0.4  # Only 40% overflow to stamina
            
            current_stamina = character.get("stamina", 100)
            new_stamina = max(0, current_stamina - stamina_damage)
            character["stamina"] = new_stamina
            
            # Overflow to life with higher threshold
            if new_stamina == 0:
                # BALANCE: Make it much harder to lose life
                life_threshold = 100  # Increased from 50
                if stamina_damage > current_stamina + life_threshold:
                    life_damage = 0.5  # Fractional life loss
                    character["life"] = max(0, character.get("life", 100) - life_damage)
                    
                    # Record life lost rStat
                    character["rStats"]["rLLS"] = character["rStats"].get("rLLS", 0) + 1
                    
                # Mark character as KO'd
                character["is_ko"] = True
                
                # Record KO in rStats if KO'd for first time this match
                if character.get("first_ko", True):
                    character["first_ko"] = False
                    
                    if character.get("division") == "o":
                        character["rStats"]["rKNBo"] = character["rStats"].get("rKNBo", 0) + 1
                    
                    # Record opponent takedown for source character
                    if source_character:
                        source_character.setdefault("rStats", {})
                        source_character["rStats"]["rOTD"] = source_character["rStats"].get("rOTD", 0) + 1
                        
                        # Award assists
                        if context.get("damage_contributors") and char_id in context["damage_contributors"]:
                            for contributor_id in context["damage_contributors"][char_id]:
                                # Skip the KO source
                                if contributor_id != source_character.get("id", "unknown"):
                                    # Find contributor and update stats
                                    for team in [context.get("team_a", []), context.get("team_b", [])]:
                                        for char in team:
                                            if char.get("id") == contributor_id:
                                                char.setdefault("rStats", {})
                                                char["rStats"]["rAST"] = char["rStats"].get("rAST", 0) + 1
                                                break
        
        return {
            "original_damage": damage,
            "reduced_damage": reduced_damage,
            "new_hp": new_hp,
            "stamina_damage": stamina_damage,
            "is_ko": character.get("is_ko", False),
            "is_dead": character.get("is_dead", False)
        }
    
    def apply_end_of_round_effects(self, characters, context, show_details=True):
        """Apply end-of-round effects with improved recovery mechanics
        
        Args:
            characters: List of characters
            context: Match context
            show_details: Whether to show detailed output
        """
        for character in characters:
            # Skip dead characters
            if character.get("is_dead", False):
                continue
                    
            # Base HP regeneration
            base_hp_regen = self.HP_REGEN_BASE
            
            # Regeneration effects from traits
            trait_heal_amount = 0
            if self.trait_system:
                trait_effects = self.trait_system.apply_trait_effect(character, "end_of_turn", {})
                
                for effect in trait_effects:
                    if effect.get("effect") == "healing":
                        # BALANCE: Moderate healing trait effectiveness
                        trait_heal_amount = effect.get("value", 0) * 2  # 2x healing effect
                        context["trait_logs"].append({
                            "round": context["round"],
                            "character": character["name"],
                            "trait": effect.get("trait_name", "Unknown"),
                            "effect": f"Healing +{trait_heal_amount}"
                        })
            
            # Apply total healing
            total_heal = base_hp_regen + trait_heal_amount
            
            # Only heal if not at full HP
            if character.get("HP", 100) < 100:
                old_hp = character.get("HP", 0)
                character["HP"] = min(100, old_hp + total_heal)
                
                # Record healing in rStats
                if trait_heal_amount > 0:
                    character.setdefault("rStats", {})
                    character["rStats"]["rHLG"] = character["rStats"].get("rHLG", 0) + trait_heal_amount
            
            # Apply stamina regeneration
            base_stamina_regen = self.STAMINA_REGEN_BASE
            
            # Apply WIL bonus to stamina regen
            wil_bonus = max(0, character.get("aWIL", 5) - 5)
            wil_regen = wil_bonus * 0.8  # 0.8 per point above 5
            
            # Apply momentum bonuses to stamina regen
            momentum_bonus = 0
            momentum_state = character.get("momentum_state", "stable")
            if momentum_state == "crash":
                momentum_bonus = 2  # +2 stamina regen in crash state (comeback mechanic)
            
            regen_rate = base_stamina_regen + wil_regen + momentum_bonus
            
            # BALANCE: Faster recovery from knockdown
            if character.get("is_ko", False):
                # KO'd characters recover faster
                regen_rate *= self.KO_RECOVERY_FACTOR
                
                # Improved chance to recover from KO based on stamina
                stamina = character.get("stamina", 0)
                if stamina > 20:  # Lowered threshold from 30
                    # Increased recovery chance
                    recovery_chance = stamina / 150  # 13-66% chance based on stamina
                    
                    # Apply WIL bonus to recovery chance
                    wil_factor = character.get("aWIL", 5) / 5.0
                    recovery_chance *= wil_factor
                    
                    if random.random() < recovery_chance:
                        character["is_ko"] = False
                        character["HP"] = max(20, character.get("HP", 0))  # Ensure at least 20 HP
                        
                        # Record recovery in rStats
                        character.setdefault("rStats", {})
                        character["rStats"]["rEVS"] = character["rStats"].get("rEVS", 0) + 1
                        
                        if show_details:
                            print(f"  {character['name']} has recovered from knockout!")
            
            character["stamina"] = min(100, character.get("stamina", 0) + regen_rate)
            
            if show_details and (total_heal > 0 or regen_rate > 0):
                print(f"  {character['name']} recovered HP: +{total_heal:.1f}, Stamina: +{regen_rate:.1f}")
    
    def select_move(self, board, character):
        """Select a move for a character based on their abilities, traits and stats
        
        Args:
            board: Chess board to select move for
            character: Character making the move
            
        Returns:
            Move: Selected chess move
        """
        if not self.stockfish_available:
            # Fallback to random move selection
            legal_moves = list(board.legal_moves)
            return random.choice(legal_moves) if legal_moves else None
        
        try:
            # Determine search depth based on character stats
            base_depth = min(max(2, character.get("aSPD", 5) // 2), 10)
            
            # Adjust depth based on stamina (lower stamina = lower depth)
            stamina_factor = max(0.5, character.get("stamina", 100) / 100)
            adjusted_depth = max(1, int(base_depth * stamina_factor))
            
            # Open Stockfish engine
            with chess.engine.SimpleEngine.popen_uci(self.stockfish_path) as engine:
                # Add thinking time based on character's Focus/Speed
                thinking_ms = character.get("aFS", 5) * 50
                
                # Get analysis from Stockfish
                limit = chess.engine.Limit(depth=adjusted_depth, time=thinking_ms/1000.0)
                
                # Determine move quality based on character stats and traits
                quality_roll = random.random()
                quality_boost = (character.get("aSTR", 5) + character.get("aFS", 5)) / 20.0
                
                # Apply trait bonuses to quality roll
                if self.trait_system:
                    trait_effects = self.trait_system.apply_trait_effect(
                        character, "move_selection", {"board": board}
                    )
                    
                    for effect in trait_effects:
                        if effect.get("effect") == "move_quality":
                            quality_boost += effect.get("value", 0) / 100.0
                
                # Apply momentum modifiers
                momentum_state = character.get("momentum_state", "stable")
                if momentum_state == "building":
                    quality_boost += 0.1  # +10% quality in building momentum
                elif momentum_state == "crash":
                    quality_boost -= 0.05  # -5% quality in crash momentum (softer penalty)
                
                quality_roll += quality_boost
                
                # Select move based on quality roll
                if quality_roll > 0.9:  # Brilliant move
                    result = engine.play(board, limit)
                    
                    # Record tactical insight in rStats
                    character.setdefault("rStats", {})
                    if character.get("division") == "i":
                        character["rStats"]["rILSi"] = character["rStats"].get("rILSi", 0) + 1
                    
                    return result.move
                elif quality_roll > 0.7:  # Good move
                    # Get top 3 moves and pick randomly from them
                    analysis = engine.analyse(board, limit, multipv=3)
                    if analysis:
                        moves = [entry["pv"][0] for entry in analysis if "pv" in entry and entry["pv"]]
                        return random.choice(moves) if moves else None
                elif quality_roll > 0.4:  # Decent move
                    # Get top 5 moves and pick randomly from them
                    analysis = engine.analyse(board, limit, multipv=5)
                    if analysis:
                        moves = [entry["pv"][0] for entry in analysis if "pv" in entry and entry["pv"]]
                        return random.choice(moves) if moves else None
                else:  # Suboptimal move
                    # Pick a random legal move with some bias for non-terrible moves
                    legal_moves = list(board.legal_moves)
                    if legal_moves:
                        # Try to avoid obvious blunders
                        if random.random() > 0.3:  # 70% chance of avoiding obvious blunders
                            info = engine.analyse(board, chess.engine.Limit(depth=1))
                            if "pv" in info and info["pv"]:
                                safe_move = info["pv"][0]
                                return safe_move
                        return random.choice(legal_moves)
        
        except Exception as e:
            print(f"Stockfish error: {e}")
            # Fallback to random move selection
            legal_moves = list(board.legal_moves)
            return random.choice(legal_moves) if legal_moves else None
        
        # Final fallback
        legal_moves = list(board.legal_moves)
        return random.choice(legal_moves) if legal_moves else None