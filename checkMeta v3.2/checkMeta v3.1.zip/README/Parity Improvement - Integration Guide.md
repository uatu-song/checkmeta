# Process convergences between boards with randomized order
    first_team, first_boards, first_id, second_team, second_boards, second_id = randomize_team_order(
        team_a, team_a_boards, team_b, team_b_boards
    )